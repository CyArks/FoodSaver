import React, { useState } from 'react';
import axios from 'axios';

const CreateRecipe = () => {
    const [formData, setFormData] = useState({
        name: '',
        ingredients: '',
        steps: ''
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!formData.name || !formData.ingredients || !formData.steps) {
            alert('All fields are required.');
            return;
        }

        axios.post('/api/recipes', formData)
            .then(response => {
                alert('Recipe created successfully!');
            })
            .catch(error => {
                alert('Error creating recipe. Please try again.');
                console.error('Error creating recipe:', error);
            });
    };

    return (
        <div>
            <h1>Create a New Recipe</h1>
            <form onSubmit={handleSubmit}>
                <input type="text" name="name" placeholder="Recipe name" onChange={handleChange} required />
                <textarea name="ingredients" placeholder="Ingredients" onChange={handleChange} required></textarea>
                <textarea name="steps" placeholder="Steps" onChange={handleChange} required></textarea>
                <button type="submit">Submit</button>
            </form>
        </div>
    );
};

export default CreateRecipe;
